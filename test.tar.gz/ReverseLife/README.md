# Reverse Game of Life by 1 generation  

How hard can it be  
