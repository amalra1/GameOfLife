# REVERSE GAME OF LIFE

[PT-BR]

Esse trabalho consiste providenciar uma possível configuração de tabuleiro **N**x**M** será um dos tabuleiros que podem ter gerado o tabuleiro **T1**, obtido na entrada do programa. </br>
